import { Artwork, User, Exhibition, Review, Category, Bid } from '../types';

// Mock users data
export const users: User[] = [
  {
    id: '1',
    name: 'Isabella Martinez',
    email: 'isabella@example.com',
    isArtist: true,
    bio: 'Contemporary artist focusing on abstract expressionism and color theory.',
    profileImage: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    createdAt: '2023-01-15T10:00:00Z',
  },
  {
    id: '2',
    name: 'James Wilson',
    email: 'james@example.com',
    isArtist: true,
    bio: 'Specializing in large-scale urban landscape photography.',
    profileImage: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
    createdAt: '2023-02-10T14:30:00Z',
  },
  {
    id: '3',
    name: 'Emma Thompson',
    email: 'emma@example.com',
    isArtist: false,
    createdAt: '2023-03-05T09:15:00Z',
    profileImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
  },
];

// Mock categories
export const categories: Category[] = [
  {
    id: '1',
    name: 'Painting',
    slug: 'painting',
    description: 'Oil, acrylic, watercolor, and mixed media paintings',
    imageUrl: 'https://images.pexels.com/photos/102127/pexels-photo-102127.jpeg',
  },
  {
    id: '2',
    name: 'Photography',
    slug: 'photography',
    description: 'Digital and film photography across various subjects',
    imageUrl: 'https://images.pexels.com/photos/1122868/pexels-photo-1122868.jpeg',
  },
  {
    id: '3',
    name: 'Sculpture',
    slug: 'sculpture',
    description: 'Three-dimensional art made by carving or other methods',
    imageUrl: 'https://images.pexels.com/photos/134402/pexels-photo-134402.jpeg',
  },
  {
    id: '4',
    name: 'Digital Art',
    slug: 'digital-art',
    description: 'Art created or presented using digital technology',
    imageUrl: 'https://images.pexels.com/photos/2156881/pexels-photo-2156881.jpeg',
  },
  {
    id: '5',
    name: 'Mixed Media',
    slug: 'mixed-media',
    description: 'Artwork incorporating multiple materials and techniques',
    imageUrl: 'https://images.pexels.com/photos/1569076/pexels-photo-1569076.jpeg',
  },
];

// Mock artworks data
export const artworks: Artwork[] = [
  {
    id: '1',
    title: 'Sunset Dreams',
    description: 'A vibrant abstract interpretation of a coastal sunset with dynamic brushstrokes and warm color palette.',
    price: 1200,
    imageUrl: 'https://images.pexels.com/photos/1000366/pexels-photo-1000366.jpeg',
    category: 'painting',
    artistId: '1',
    forAuction: true,
    auctionEndDate: '2024-06-30T23:59:59Z',
    currentBid: 1350,
    createdAt: '2023-04-20T11:20:00Z',
    dimensions: '36 x 48 inches',
    medium: 'Oil on canvas',
  },
  {
    id: '2',
    title: 'Urban Geometry',
    description: 'Black and white photography highlighting the geometric patterns found in modern architecture.',
    price: 800,
    imageUrl: 'https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg',
    category: 'photography',
    artistId: '2',
    forAuction: false,
    createdAt: '2023-05-15T16:45:00Z',
    dimensions: '24 x 36 inches',
    medium: 'Digital photography, archival print',
  },
  {
    id: '3',
    title: 'Ephemeral Bloom',
    description: 'A delicate study of spring flowers using transparent watercolor techniques to capture light and texture.',
    price: 650,
    imageUrl: 'https://images.pexels.com/photos/1166209/pexels-photo-1166209.jpeg',
    category: 'painting',
    artistId: '1',
    forAuction: false,
    createdAt: '2023-06-02T09:30:00Z',
    dimensions: '18 x 24 inches',
    medium: 'Watercolor on paper',
  },
  {
    id: '4',
    title: 'City Lights',
    description: 'Long exposure photography capturing the energy of city streets at night with trails of light.',
    price: 950,
    imageUrl: 'https://images.pexels.com/photos/3052353/pexels-photo-3052353.jpeg',
    category: 'photography',
    artistId: '2',
    forAuction: true,
    auctionEndDate: '2024-06-15T23:59:59Z',
    currentBid: 1050,
    createdAt: '2023-03-10T14:15:00Z',
    dimensions: '30 x 40 inches',
    medium: 'Digital photography, archival print',
  },
  {
    id: '5',
    title: 'Harmony in Blue',
    description: 'An abstract composition exploring the emotional resonance of blue tones and fluid forms.',
    price: 1500,
    imageUrl: 'https://images.pexels.com/photos/1568607/pexels-photo-1568607.jpeg',
    category: 'painting',
    artistId: '1',
    forAuction: false,
    createdAt: '2023-02-28T10:45:00Z',
    dimensions: '40 x 60 inches',
    medium: 'Acrylic on canvas',
  },
  {
    id: '6',
    title: 'Digital Dreamscape',
    description: 'A surreal digital illustration combining photographic elements with 3D rendering techniques.',
    price: 750,
    imageUrl: 'https://images.pexels.com/photos/2832382/pexels-photo-2832382.jpeg',
    category: 'digital-art',
    artistId: '2',
    forAuction: true,
    auctionEndDate: '2024-07-10T23:59:59Z',
    currentBid: 800,
    createdAt: '2023-01-05T17:30:00Z',
    dimensions: '20 x 30 inches',
    medium: 'Digital illustration, archival print',
  },
];

// Add artist data to artworks
export const artworksWithArtists = artworks.map(artwork => {
  const artist = users.find(user => user.id === artwork.artistId);
  return { ...artwork, artist };
});

// Mock exhibitions data
export const exhibitions: Exhibition[] = [
  {
    id: '1',
    title: 'Urban Perspectives',
    description: 'An exploration of city life through various artistic lenses, featuring photography and paintings that capture the essence of urban living.',
    startDate: '2024-06-15T10:00:00Z',
    endDate: '2024-07-15T18:00:00Z',
    coverImage: 'https://images.pexels.com/photos/1674049/pexels-photo-1674049.jpeg',
    artworks: ['2', '4', '6'],
  },
  {
    id: '2',
    title: 'Colors of Emotion',
    description: 'This exhibition delves into how artists use color to evoke and express emotional states, featuring a range of abstract and representational works.',
    startDate: '2024-08-01T10:00:00Z',
    endDate: '2024-09-01T18:00:00Z',
    coverImage: 'https://images.pexels.com/photos/1568607/pexels-photo-1568607.jpeg',
    artworks: ['1', '3', '5'],
  },
];

// Mock reviews data
export const reviews: Review[] = [
  {
    id: '1',
    artworkId: '1',
    userId: '3',
    rating: 5,
    comment: 'The vibrant colors in this piece create such a powerful emotional impact. One of my favorite purchases!',
    createdAt: '2024-05-15T14:30:00Z',
    user: users.find(user => user.id === '3'),
  },
  {
    id: '2',
    artworkId: '2',
    userId: '3',
    rating: 4,
    comment: 'The stark contrast and geometric precision in this photograph is mesmerizing.',
    createdAt: '2024-05-20T09:45:00Z',
    user: users.find(user => user.id === '3'),
  },
  {
    id: '3',
    artworkId: '3',
    userId: '3',
    rating: 5,
    comment: 'The delicate watercolor technique beautifully captures the ephemeral nature of the subject.',
    createdAt: '2024-05-25T16:20:00Z',
    user: users.find(user => user.id === '3'),
  },
];

// Mock bids data
export const bids: Bid[] = [
  {
    id: '1',
    artworkId: '1',
    userId: '3',
    amount: 1250,
    createdAt: '2024-05-10T13:45:00Z',
    user: users.find(user => user.id === '3'),
  },
  {
    id: '2',
    artworkId: '1',
    userId: '3',
    amount: 1350,
    createdAt: '2024-05-12T10:30:00Z',
    user: users.find(user => user.id === '3'),
  },
  {
    id: '3',
    artworkId: '4',
    userId: '3',
    amount: 1000,
    createdAt: '2024-05-15T15:20:00Z',
    user: users.find(user => user.id === '3'),
  },
  {
    id: '4',
    artworkId: '4',
    userId: '3',
    amount: 1050,
    createdAt: '2024-05-16T09:10:00Z',
    user: users.find(user => user.id === '3'),
  },
];