export interface User {
  id: string;
  name: string;
  email: string;
  isArtist: boolean;
  bio?: string;
  profileImage?: string;
  createdAt: string;
}

export interface Artwork {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  artistId: string;
  artist?: User;
  forAuction: boolean;
  auctionEndDate?: string;
  currentBid?: number;
  createdAt: string;
  dimensions?: string;
  medium?: string;
}

export interface Exhibition {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  coverImage: string;
  artworks: string[]; // Array of artwork IDs
}

export interface Review {
  id: string;
  artworkId: string;
  userId: string;
  rating: number;
  comment: string;
  createdAt: string;
  user?: User;
}

export interface Bid {
  id: string;
  artworkId: string;
  userId: string;
  amount: number;
  createdAt: string;
  user?: User;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  imageUrl?: string;
}