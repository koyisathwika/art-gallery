import React from 'react';
import { Link } from 'react-router-dom';
import { Paintbrush, UserCircle } from 'lucide-react';

const JoinCommunity: React.FC = () => {
  return (
    <section className="py-20 bg-indigo-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Join Our Vibrant Art Community</h2>
            <p className="text-indigo-200 text-lg mb-8">
              Whether you're an artist looking to showcase your work or an art enthusiast eager to discover new pieces, ArtVista offers a platform to connect, engage, and celebrate creativity.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
              <div className="bg-indigo-800 bg-opacity-50 p-6 rounded-lg">
                <div className="bg-indigo-700 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <Paintbrush className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">For Artists</h3>
                <ul className="space-y-2 text-indigo-200">
                  <li>• Showcase your portfolio</li>
                  <li>• Sell artwork commission-free</li>
                  <li>• Participate in exhibitions</li>
                  <li>• Connect with collectors</li>
                </ul>
              </div>
              
              <div className="bg-indigo-800 bg-opacity-50 p-6 rounded-lg">
                <div className="bg-indigo-700 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <UserCircle className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2">For Collectors</h3>
                <ul className="space-y-2 text-indigo-200">
                  <li>• Discover unique artwork</li>
                  <li>• Build your collection</li>
                  <li>• Support emerging artists</li>
                  <li>• Attend exclusive events</li>
                </ul>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/signup"
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 transition duration-150"
              >
                Create an Account
              </Link>
              <Link
                to="/about"
                className="inline-flex items-center justify-center px-6 py-3 border border-indigo-300 text-base font-medium rounded-md text-white hover:bg-indigo-800 transition duration-150"
              >
                Learn More
              </Link>
            </div>
          </div>
          
          <div className="hidden lg:block">
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img 
                    src="https://images.pexels.com/photos/1266808/pexels-photo-1266808.jpeg" 
                    alt="Artist painting" 
                    className="rounded-lg shadow-xl h-48 w-full object-cover"
                  />
                  <img 
                    src="https://images.pexels.com/photos/1509534/pexels-photo-1509534.jpeg" 
                    alt="Exhibition" 
                    className="rounded-lg shadow-xl h-64 w-full object-cover"
                  />
                </div>
                <div className="space-y-4 mt-8">
                  <img 
                    src="https://images.pexels.com/photos/3328144/pexels-photo-3328144.jpeg" 
                    alt="Collector examining artwork" 
                    className="rounded-lg shadow-xl h-64 w-full object-cover"
                  />
                  <img 
                    src="https://images.pexels.com/photos/1509582/pexels-photo-1509582.jpeg" 
                    alt="Art studio" 
                    className="rounded-lg shadow-xl h-48 w-full object-cover"
                  />
                </div>
              </div>
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-amber-400 rounded-full opacity-30 blur-xl"></div>
              <div className="absolute -bottom-8 -right-8 w-40 h-40 bg-indigo-400 rounded-full opacity-30 blur-xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default JoinCommunity;