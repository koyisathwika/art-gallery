import React from 'react';
import { Star } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatar: string;
  quote: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Collector',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
    quote: 'ArtVista has transformed how I discover and purchase art. The curation is exceptional, and I\'ve found several pieces that are now the centerpiece of my home.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Artist',
    avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg',
    quote: 'As an emerging artist, finding platforms to showcase my work has been challenging. ArtVista has connected me with collectors who truly appreciate my vision.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Jessica Rivera',
    role: 'Interior Designer',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
    quote: 'I regularly use ArtVista to source unique pieces for my clients. The variety and quality of artwork available is unmatched by any other platform I\'ve used.',
    rating: 4,
  },
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">What Our Community Says</h2>
          <p className="mt-2 text-lg text-gray-600 max-w-2xl mx-auto">
            Read what artists and collectors have to say about their experience with ArtVista
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center space-x-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i}
                    className={`h-5 w-5 ${i < testimonial.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`}
                  />
                ))}
              </div>
              
              <blockquote className="text-gray-700 italic mb-6">
                "{testimonial.quote}"
              </blockquote>
              
              <div className="flex items-center">
                <img
                  src={testimonial.avatar}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;