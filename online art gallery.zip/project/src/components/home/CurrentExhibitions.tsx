import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { exhibitions } from '../../data/mockData';
import ExhibitionCard from '../common/ExhibitionCard';

const CurrentExhibitions: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Current Exhibitions</h2>
            <p className="mt-2 text-lg text-gray-600">Explore our curated exhibitions featuring exceptional artwork</p>
          </div>
          <Link 
            to="/exhibitions" 
            className="mt-4 md:mt-0 inline-flex items-center text-indigo-600 hover:text-indigo-700 font-medium"
          >
            View all exhibitions <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {exhibitions.map((exhibition) => (
            <ExhibitionCard key={exhibition.id} exhibition={exhibition} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CurrentExhibitions;