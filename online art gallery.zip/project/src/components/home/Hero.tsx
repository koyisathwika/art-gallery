import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-r from-indigo-900 to-purple-900">
      {/* Background overlay with pattern */}
      <div 
        className="absolute inset-0 opacity-10" 
        style={{ 
          backgroundImage: 'url("https://images.pexels.com/photos/1918290/pexels-photo-1918290.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      ></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 lg:py-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="max-w-xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight">
              Discover and Collect Exceptional Artwork
            </h1>
            <p className="mt-4 text-lg text-indigo-100">
              Explore our curated collection of contemporary art from emerging and established artists worldwide. Find pieces that speak to you and bring them into your life.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Link
                to="/browse"
                className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 transition duration-150"
              >
                Browse Artwork
              </Link>
              <Link
                to="/browse?auction=true"
                className="inline-flex items-center justify-center px-6 py-3 border border-indigo-300 text-base font-medium rounded-md text-white hover:bg-indigo-800 transition duration-150"
              >
                View Live Auctions
              </Link>
            </div>
          </div>

          <div className="hidden lg:block relative">
            <div className="flex gap-4 items-end">
              <div className="flex flex-col gap-4 -mb-16">
                <img
                  src="https://images.pexels.com/photos/1568607/pexels-photo-1568607.jpeg"
                  alt="Abstract artwork"
                  className="w-full h-60 object-cover rounded-lg shadow-xl transform rotate-2 hover:rotate-0 transition-transform duration-300"
                />
                <img
                  src="https://images.pexels.com/photos/1000366/pexels-photo-1000366.jpeg"
                  alt="Colorful painting"
                  className="w-full h-48 object-cover rounded-lg shadow-xl -rotate-3 hover:rotate-0 transition-transform duration-300"
                />
              </div>
              <div className="flex flex-col gap-4">
                <img
                  src="https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg"
                  alt="Black and white photograph"
                  className="w-full h-72 object-cover rounded-lg shadow-xl -rotate-1 hover:rotate-0 transition-transform duration-300"
                />
                <img
                  src="https://images.pexels.com/photos/1674049/pexels-photo-1674049.jpeg"
                  alt="Contemporary sculpture"
                  className="w-full h-60 object-cover rounded-lg shadow-xl rotate-3 hover:rotate-0 transition-transform duration-300"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Featured in section */}
        <div className="mt-16 lg:mt-20 border-t border-indigo-800 pt-8">
          <p className="text-center text-indigo-300 text-sm uppercase tracking-wider font-medium mb-6">
            As Featured In
          </p>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6">
            <div className="text-white/60 font-serif text-xl">ArtForum</div>
            <div className="text-white/60 font-sans font-bold text-xl">MODERN ART</div>
            <div className="text-white/60 italic text-xl">The Gallery Times</div>
            <div className="text-white/60 font-mono text-xl">CANVAS</div>
            <div className="text-white/60 font-serif text-xl">ArtReview</div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 mb-8 animate-bounce">
        <ChevronRight className="h-8 w-8 text-white/50 rotate-90" />
      </div>
    </div>
  );
};

export default Hero;