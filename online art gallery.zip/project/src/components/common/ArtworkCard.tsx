import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Heart } from 'lucide-react';
import { Artwork } from '../../types';

interface ArtworkCardProps {
  artwork: Artwork;
}

const ArtworkCard: React.FC<ArtworkCardProps> = ({ artwork }) => {
  const isAuction = artwork.forAuction;
  const displayPrice = isAuction 
    ? `Current Bid: $${artwork.currentBid?.toLocaleString() || artwork.price.toLocaleString()}`
    : `$${artwork.price.toLocaleString()}`;

  // Calculate remaining time for auction (if applicable)
  const getTimeRemaining = () => {
    if (!artwork.auctionEndDate) return '';
    
    const now = new Date();
    const endDate = new Date(artwork.auctionEndDate);
    const timeRemaining = endDate.getTime() - now.getTime();
    
    // If auction has ended
    if (timeRemaining <= 0) return 'Auction ended';
    
    const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) {
      return `${days}d ${hours}h remaining`;
    } else {
      const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m remaining`;
    }
  };

  return (
    <div className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300">
      <Link to={`/artwork/${artwork.id}`} className="block relative overflow-hidden aspect-[3/4]">
        <img
          src={artwork.imageUrl}
          alt={artwork.title}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
        />
        <button 
          className="absolute top-3 right-3 bg-white bg-opacity-80 p-2 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          aria-label="Add to favorites"
        >
          <Heart className="w-5 h-5 text-gray-600 hover:text-red-500 transition-colors duration-150" />
        </button>
      </Link>
      
      <div className="p-4">
        <Link to={`/artwork/${artwork.id}`} className="block">
          <h3 className="font-semibold text-lg mb-1 text-gray-900 hover:text-indigo-600 transition-colors duration-150">
            {artwork.title}
          </h3>
        </Link>
        
        <Link to={`/artist/${artwork.artistId}`} className="text-sm text-gray-600 hover:text-indigo-600 transition-colors duration-150">
          {artwork.artist?.name || 'Unknown Artist'}
        </Link>
        
        <div className="mt-3 flex justify-between items-center">
          <span className="font-medium text-gray-900">{displayPrice}</span>
          
          {isAuction && artwork.auctionEndDate && (
            <div className="flex items-center text-xs text-amber-600">
              <Clock className="w-3 h-3 mr-1" />
              {getTimeRemaining()}
            </div>
          )}
        </div>
        
        <div className="mt-4 flex space-x-2">
          <Link 
            to={`/artwork/${artwork.id}`} 
            className={`text-sm px-3 py-1.5 rounded-md transition-colors duration-150 ${
              isAuction 
                ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' 
                : 'bg-indigo-100 text-indigo-800 hover:bg-indigo-200'
            }`}
          >
            {isAuction ? 'Place Bid' : 'View Details'}
          </Link>
          {!isAuction && (
            <button className="text-sm px-3 py-1.5 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors duration-150">
              Add to Cart
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ArtworkCard;