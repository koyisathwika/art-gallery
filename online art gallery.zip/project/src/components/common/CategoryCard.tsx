import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link 
      to={`/browse?category=${category.slug}`}
      className="group relative overflow-hidden rounded-lg shadow-md h-48"
    >
      <img 
        src={category.imageUrl} 
        alt={category.name}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-5">
        <h3 className="text-xl font-bold text-white">{category.name}</h3>
        {category.description && (
          <p className="text-sm text-gray-200 mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            {category.description}
          </p>
        )}
      </div>
    </Link>
  );
};

export default CategoryCard;