import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar } from 'lucide-react';
import { Exhibition } from '../../types';

interface ExhibitionCardProps {
  exhibition: Exhibition;
}

const ExhibitionCard: React.FC<ExhibitionCardProps> = ({ exhibition }) => {
  // Format dates
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const startDate = formatDate(exhibition.startDate);
  const endDate = formatDate(exhibition.endDate);

  // Check if the exhibition is current, upcoming, or past
  const now = new Date();
  const exhibitionStart = new Date(exhibition.startDate);
  const exhibitionEnd = new Date(exhibition.endDate);
  
  let status = '';
  let statusClass = '';
  
  if (now < exhibitionStart) {
    status = 'Upcoming';
    statusClass = 'bg-blue-100 text-blue-800';
  } else if (now > exhibitionEnd) {
    status = 'Past';
    statusClass = 'bg-gray-100 text-gray-800';
  } else {
    status = 'Now On';
    statusClass = 'bg-green-100 text-green-800';
  }

  return (
    <div className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300">
      <Link to={`/exhibition/${exhibition.id}`} className="block relative overflow-hidden aspect-[16/9]">
        <img
          src={exhibition.coverImage}
          alt={exhibition.title}
          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span className={`text-xs font-semibold px-2 py-1 rounded-full ${statusClass}`}>
            {status}
          </span>
        </div>
      </Link>
      
      <div className="p-4">
        <Link to={`/exhibition/${exhibition.id}`} className="block">
          <h3 className="font-semibold text-lg mb-2 text-gray-900 hover:text-indigo-600 transition-colors duration-150">
            {exhibition.title}
          </h3>
        </Link>
        
        <div className="flex items-center text-sm text-gray-600 mb-3">
          <Calendar className="w-4 h-4 mr-2" />
          <span>{startDate} - {endDate}</span>
        </div>
        
        <p className="text-gray-600 text-sm line-clamp-2 mb-4">
          {exhibition.description}
        </p>
        
        <Link 
          to={`/exhibition/${exhibition.id}`} 
          className="inline-block text-sm px-4 py-2 bg-indigo-100 text-indigo-800 rounded-md hover:bg-indigo-200 transition-colors duration-150"
        >
          View Exhibition
        </Link>
      </div>
    </div>
  );
};

export default ExhibitionCard;