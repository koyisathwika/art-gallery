import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Filter, X, ChevronDown, Search as SearchIcon } from 'lucide-react';
import { Artwork, Category } from '../types';
import { artworksWithArtists, categories } from '../data/mockData';
import ArtworkCard from '../components/common/ArtworkCard';

const BrowsePage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredArtworks, setFilteredArtworks] = useState<Artwork[]>([]);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Get filter parameters from URL
  const categoryParam = searchParams.get('category');
  const searchQuery = searchParams.get('search') || '';
  const priceMinParam = searchParams.get('price_min');
  const priceMaxParam = searchParams.get('price_max');
  const auctionParam = searchParams.get('auction');
  
  // Filter state
  const [selectedCategory, setSelectedCategory] = useState<string>(categoryParam || '');
  const [priceRange, setPriceRange] = useState<{ min: number; max: number | null }>({
    min: priceMinParam ? parseInt(priceMinParam) : 0,
    max: priceMaxParam ? parseInt(priceMaxParam) : null
  });
  const [search, setSearch] = useState<string>(searchQuery || '');
  const [isAuction, setIsAuction] = useState<boolean | null>(
    auctionParam ? auctionParam === 'true' : null
  );

  // Price range options
  const priceRanges = [
    { label: 'Any Price', min: 0, max: null },
    { label: 'Under $500', min: 0, max: 500 },
    { label: '$500 - $1,000', min: 500, max: 1000 },
    { label: '$1,000 - $2,500', min: 1000, max: 2500 },
    { label: '$2,500 - $5,000', min: 2500, max: 5000 },
    { label: '$5,000+', min: 5000, max: null }
  ];

  // Update URL search params when filters change
  useEffect(() => {
    const newSearchParams = new URLSearchParams();
    
    if (selectedCategory) newSearchParams.set('category', selectedCategory);
    if (search) newSearchParams.set('search', search);
    if (priceRange.min > 0) newSearchParams.set('price_min', priceRange.min.toString());
    if (priceRange.max) newSearchParams.set('price_max', priceRange.max.toString());
    if (isAuction !== null) newSearchParams.set('auction', isAuction.toString());
    
    setSearchParams(newSearchParams);
  }, [selectedCategory, search, priceRange, isAuction, setSearchParams]);

  // Filter artworks based on selected filters
  useEffect(() => {
    let results = [...artworksWithArtists];
    
    // Filter by category
    if (selectedCategory) {
      results = results.filter(artwork => artwork.category === selectedCategory);
    }
    
    // Filter by search query
    if (search) {
      const query = search.toLowerCase();
      results = results.filter(artwork => 
        artwork.title.toLowerCase().includes(query) || 
        artwork.description.toLowerCase().includes(query) ||
        (artwork.artist?.name && artwork.artist.name.toLowerCase().includes(query))
      );
    }
    
    // Filter by price range
    if (priceRange.min > 0 || priceRange.max) {
      results = results.filter(artwork => {
        const price = artwork.forAuction && artwork.currentBid ? artwork.currentBid : artwork.price;
        return (
          price >= priceRange.min && 
          (priceRange.max === null || price <= priceRange.max)
        );
      });
    }
    
    // Filter by auction status
    if (isAuction !== null) {
      results = results.filter(artwork => artwork.forAuction === isAuction);
    }
    
    setFilteredArtworks(results);
  }, [selectedCategory, search, priceRange, isAuction, artworksWithArtists]);

  // Update page title
  useEffect(() => {
    document.title = "Browse Artwork | ArtVista";
  }, []);

  // Handle category change
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category === selectedCategory ? '' : category);
  };

  // Handle price range change
  const handlePriceRangeChange = (min: number, max: number | null) => {
    setPriceRange({ min, max });
  };

  // Handle auction filter change
  const handleAuctionFilterChange = (value: boolean | null) => {
    setIsAuction(value);
  };

  // Handle search submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Search is updated by the input's onChange event
  };

  // Reset all filters
  const resetFilters = () => {
    setSelectedCategory('');
    setSearch('');
    setPriceRange({ min: 0, max: null });
    setIsAuction(null);
  };

  // Count the number of active filters
  const activeFiltersCount = [
    selectedCategory,
    search,
    priceRange.min > 0 || priceRange.max !== null,
    isAuction !== null
  ].filter(Boolean).length;

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="bg-white py-8 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">Browse Artwork</h1>
          <p className="mt-2 text-lg text-gray-600">
            Discover and collect exceptional pieces from our curated collection
          </p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Mobile filter dialog */}
          <div className="lg:hidden flex items-center justify-between mb-4">
            <button
              onClick={() => setIsFilterOpen(!isFilterOpen)}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <span className="ml-2 bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full text-xs">
                  {activeFiltersCount}
                </span>
              )}
            </button>
            
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                placeholder="Search art..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-md w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </form>
          </div>
          
          {/* Mobile filters */}
          <div
            className={`fixed inset-0 z-40 lg:hidden bg-gray-600 bg-opacity-75 transition-opacity ${
              isFilterOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            onClick={() => setIsFilterOpen(false)}
          >
            <div
              className={`fixed inset-y-0 left-0 z-40 w-full bg-white transform transition ease-in-out duration-300 ${
                isFilterOpen ? 'translate-x-0' : '-translate-x-full'
              }`}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="h-full flex flex-col p-6 overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Filters</h2>
                  <button
                    type="button"
                    className="text-gray-500 hover:text-gray-600"
                    onClick={() => setIsFilterOpen(false)}
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>
                
                {/* Filter content - same as desktop but adapted for mobile */}
                <div className="space-y-6">
                  {/* Categories filter */}
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Categories</h3>
                    <div className="space-y-2">
                      {categories.map((category) => (
                        <div key={category.id} className="flex items-center">
                          <button
                            onClick={() => handleCategoryChange(category.slug)}
                            className={`flex-1 text-left px-3 py-2 rounded-md ${
                              selectedCategory === category.slug
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'hover:bg-gray-50'
                            }`}
                          >
                            {category.name}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Price range filter */}
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Price Range</h3>
                    <div className="space-y-2">
                      {priceRanges.map((range, index) => (
                        <div key={index} className="flex items-center">
                          <button
                            onClick={() => handlePriceRangeChange(range.min, range.max)}
                            className={`flex-1 text-left px-3 py-2 rounded-md ${
                              priceRange.min === range.min && priceRange.max === range.max
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'hover:bg-gray-50'
                            }`}
                          >
                            {range.label}
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Auction filter */}
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-3">Type</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <button
                          onClick={() => handleAuctionFilterChange(null)}
                          className={`flex-1 text-left px-3 py-2 rounded-md ${
                            isAuction === null
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'hover:bg-gray-50'
                          }`}
                        >
                          All Items
                        </button>
                      </div>
                      <div className="flex items-center">
                        <button
                          onClick={() => handleAuctionFilterChange(false)}
                          className={`flex-1 text-left px-3 py-2 rounded-md ${
                            isAuction === false
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'hover:bg-gray-50'
                          }`}
                        >
                          Buy Now
                        </button>
                      </div>
                      <div className="flex items-center">
                        <button
                          onClick={() => handleAuctionFilterChange(true)}
                          className={`flex-1 text-left px-3 py-2 rounded-md ${
                            isAuction === true
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'hover:bg-gray-50'
                          }`}
                        >
                          Auction
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Reset filters button */}
                  {activeFiltersCount > 0 && (
                    <div className="pt-4">
                      <button
                        onClick={resetFilters}
                        className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Reset Filters
                      </button>
                    </div>
                  )}
                </div>
                
                <div className="mt-auto pt-6">
                  <button
                    type="button"
                    className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    onClick={() => setIsFilterOpen(false)}
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {/* Desktop filters */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-white p-6 rounded-lg shadow-sm sticky top-20">
              <div className="space-y-6">
                {/* Search */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Search</h3>
                  <form onSubmit={handleSearchSubmit} className="relative">
                    <input
                      type="text"
                      placeholder="Search art..."
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-md w-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                    />
                    <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </form>
                </div>
                
                {/* Categories filter */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Categories</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center">
                        <button
                          onClick={() => handleCategoryChange(category.slug)}
                          className={`flex-1 text-left px-3 py-2 rounded-md text-sm ${
                            selectedCategory === category.slug
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          {category.name}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Price range filter */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Price Range</h3>
                  <div className="space-y-2">
                    {priceRanges.map((range, index) => (
                      <div key={index} className="flex items-center">
                        <button
                          onClick={() => handlePriceRangeChange(range.min, range.max)}
                          className={`flex-1 text-left px-3 py-2 rounded-md text-sm ${
                            priceRange.min === range.min && priceRange.max === range.max
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          {range.label}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Auction filter */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3">Type</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <button
                        onClick={() => handleAuctionFilterChange(null)}
                        className={`flex-1 text-left px-3 py-2 rounded-md text-sm ${
                          isAuction === null
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'hover:bg-gray-50 text-gray-700'
                        }`}
                      >
                        All Items
                      </button>
                    </div>
                    <div className="flex items-center">
                      <button
                        onClick={() => handleAuctionFilterChange(false)}
                        className={`flex-1 text-left px-3 py-2 rounded-md text-sm ${
                          isAuction === false
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'hover:bg-gray-50 text-gray-700'
                        }`}
                      >
                        Buy Now
                      </button>
                    </div>
                    <div className="flex items-center">
                      <button
                        onClick={() => handleAuctionFilterChange(true)}
                        className={`flex-1 text-left px-3 py-2 rounded-md text-sm ${
                          isAuction === true
                            ? 'bg-indigo-100 text-indigo-800'
                            : 'hover:bg-gray-50 text-gray-700'
                        }`}
                      >
                        Auction
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* Reset filters button */}
                {activeFiltersCount > 0 && (
                  <div className="pt-4">
                    <button
                      onClick={resetFilters}
                      className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Reset Filters
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Results */}
          <div className="flex-1">
            {/* Active filters */}
            {activeFiltersCount > 0 && (
              <div className="bg-white p-4 rounded-lg shadow-sm mb-6 flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium text-gray-700 mr-2">Active filters:</span>
                
                {selectedCategory && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                    {categories.find(c => c.slug === selectedCategory)?.name || selectedCategory}
                    <button
                      type="button"
                      className="ml-1 inline-flex"
                      onClick={() => setSelectedCategory('')}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                )}
                
                {search && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                    Search: {search}
                    <button
                      type="button"
                      className="ml-1 inline-flex"
                      onClick={() => setSearch('')}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                )}
                
                {(priceRange.min > 0 || priceRange.max !== null) && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                    Price: 
                    {priceRange.min > 0 && `$${priceRange.min.toLocaleString()}`}
                    {priceRange.min > 0 && priceRange.max && ' - '}
                    {priceRange.max && `$${priceRange.max.toLocaleString()}`}
                    {!priceRange.max && priceRange.min > 0 && '+'}
                    <button
                      type="button"
                      className="ml-1 inline-flex"
                      onClick={() => setPriceRange({ min: 0, max: null })}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                )}
                
                {isAuction !== null && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                    {isAuction ? 'Auction Only' : 'Buy Now Only'}
                    <button
                      type="button"
                      className="ml-1 inline-flex"
                      onClick={() => setIsAuction(null)}
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                )}
                
                <button
                  type="button"
                  className="ml-auto text-sm text-indigo-600 hover:text-indigo-500"
                  onClick={resetFilters}
                >
                  Clear all
                </button>
              </div>
            )}
            
            {/* Sort and count */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6 flex flex-wrap items-center justify-between">
              <p className="text-sm text-gray-700">
                Showing <span className="font-medium">{filteredArtworks.length}</span> artworks
              </p>
              
              <div className="relative">
                <select
                  className="appearance-none pl-3 pr-10 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  defaultValue="newest"
                >
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="popular">Most Popular</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
            
            {/* Artwork grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredArtworks.length > 0 ? (
                filteredArtworks.map((artwork) => (
                  <ArtworkCard key={artwork.id} artwork={artwork} />
                ))
              ) : (
                <div className="col-span-full py-12 flex flex-col items-center justify-center text-center">
                  <img 
                    src="https://images.pexels.com/photos/4349754/pexels-photo-4349754.jpeg" 
                    alt="No results" 
                    className="w-48 h-48 object-cover rounded-full mb-6 opacity-70"
                  />
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">No artwork found</h3>
                  <p className="text-gray-600 mb-4 max-w-md">
                    We couldn't find any artwork matching your current filters. Try adjusting your search criteria.
                  </p>
                  <button
                    onClick={resetFilters}
                    className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    Reset Filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrowsePage;