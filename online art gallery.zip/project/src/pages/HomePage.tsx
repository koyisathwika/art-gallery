import React from 'react';
import Hero from '../components/home/Hero';
import FeaturedCategories from '../components/home/FeaturedCategories';
import FeaturedArtworks from '../components/home/FeaturedArtworks';
import CurrentExhibitions from '../components/home/CurrentExhibitions';
import JoinCommunity from '../components/home/JoinCommunity';
import Testimonials from '../components/home/Testimonials';

const HomePage: React.FC = () => {
  // Update page title
  React.useEffect(() => {
    document.title = "ArtVista | Discover and Collect Exceptional Artwork";
  }, []);

  return (
    <div>
      <Hero />
      <FeaturedCategories />
      <FeaturedArtworks />
      <CurrentExhibitions />
      <JoinCommunity />
      <Testimonials />
    </div>
  );
};

export default HomePage;